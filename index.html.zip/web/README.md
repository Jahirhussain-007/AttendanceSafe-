# AttendanceSafe (web)
Open `index.html` in a browser, or deploy the folder as a static site.

Deploy: go to app.netlify.com/drop and drag `index.html` (or this folder) onto the page.
Tests (logic only): `node tests/tracker.test.js`

Daily tracker: 5 one-hour boxes per day (✓ present / ✕ absent / tap again to clear). Totals = opening hours in the form + tracked hours. Data is saved in the browser (localStorage) and survives refresh and restart; clearing browser data erases it.

## First-time setup, profile and settings
New users see a 2-step setup (attendance numbers, then student profile). Users with data from an older version keep their attendance data and only fill in the profile once. Settings (⚙ in the header) lets you edit the profile, attendance numbers, and Reset Setup (asks for confirmation). Profile and photo stay on this device only (no login or server). Storage keys: attendancesafe:v2 (attendance numbers), :v3:days (daily records), :v4 (setup status and profile).
